import { analyzeProblem, type AnalyzeInput } from "@/lib/ai";
import { getReportsForDuplicates } from "@/lib/data";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

function toFeatures(value: unknown): AnalyzeInput["imageFeatures"] {
  if (!value || typeof value !== "object") return null;
  const record = value as Record<string, unknown>;
  const numbers = ["brightness", "saturation", "greenness", "grayness"].map((key) =>
    typeof record[key] === "number" ? (record[key] as number) : NaN,
  );
  if (numbers.some((n) => !Number.isFinite(n))) return null;
  const [brightness, saturation, greenness, grayness] = numbers;
  return { brightness, saturation, greenness, grayness };
}

export async function POST(request: Request) {
  try {
    await ensureSeeded();
    const body = (await request.json()) as Record<string, unknown>;
    const description = typeof body.description === "string" ? body.description : "";
    const title = typeof body.title === "string" ? body.title : "";

    if (description.trim().length < 8 && !body.imageSampleKey) {
      return Response.json(
        { error: "Add a few more words about the problem so the text model has something to read." },
        { status: 400 },
      );
    }

    const existing = await getReportsForDuplicates();
    const analysis = analyzeProblem(
      {
        title,
        description,
        language: typeof body.language === "string" ? body.language : "en",
        neighbourhood: typeof body.neighbourhood === "string" ? body.neighbourhood : undefined,
        address: typeof body.address === "string" ? body.address : undefined,
        lat: typeof body.lat === "number" ? body.lat : undefined,
        lng: typeof body.lng === "number" ? body.lng : undefined,
        imageSampleKey: typeof body.imageSampleKey === "string" ? body.imageSampleKey : null,
        imageFeatures: toFeatures(body.imageFeatures),
      },
      existing,
    );

    return Response.json({ analysis, existingCount: existing.length });
  } catch {
    return Response.json(
      { error: "The analysis service is unavailable. Please try again in a moment." },
      { status: 500 },
    );
  }
}
