/* eslint-disable @next/next/no-img-element */
import Link from "next/link";
import ReportCard from "@/components/ReportCard";
import {
  Avatar,
  CategoryGlyph,
  CategoryLegend,
  SectionLabel,
} from "@/components/ui";
import { getAllReports, getLeaderboard, getPlatformStats } from "@/lib/data";
import { ensureSeeded } from "@/lib/seed";
import { CATEGORIES, categoryMeta } from "@/lib/types";

const PIPELINE = [
  {
    step: "01",
    title: "Observe",
    copy: "Snap a photo, speak in your language or type a few words about what is wrong.",
  },
  {
    step: "02",
    title: "Analyse",
    copy: "Vision and text models read the evidence, extract the damage pattern and the risk words.",
  },
  {
    step: "03",
    title: "Classify & prioritise",
    copy: "A category, confidence score and priority band are suggested — always editable by a human.",
  },
  {
    step: "04",
    title: "De-duplicate",
    copy: "Similar reports nearby are grouped into one action thread instead of inflating the count.",
  },
  {
    step: "05",
    title: "Track & act",
    copy: "Residents and civic teams follow one trail from open to resolved, earning impact points.",
  },
];

export default async function HomePage() {
  await ensureSeeded();
  const [allReports, leaders] = await Promise.all([getAllReports(), getLeaderboard()]);
  const stats = await getPlatformStats(allReports, leaders);

  const heroReport =
    allReports.find((report) => report.category === "garbage" && report.duplicateCount > 0) ??
    allReports.find((report) => report.priority === "high") ??
    allReports[0];

  const featured = [
    ...allReports.filter((report) => report.status !== "resolved" && report.priority === "high"),
    ...allReports.filter((report) => report.status !== "resolved"),
  ]
    .filter((report, index, list) => list.findIndex((r) => r.id === report.id) === index)
    .slice(0, 3);

  const grouped = allReports.find((report) => report.duplicateCount > 1);

  return (
    <div>
      {/* HERO */}
      <section className="relative overflow-hidden border-b border-line">
        <div className="grid-paper pointer-events-none absolute inset-0 opacity-60" />
        <div className="pointer-events-none absolute -right-32 -top-40 h-[420px] w-[420px] rounded-full bg-lime/35 blur-3xl" />
        <div className="relative mx-auto grid max-w-[1180px] items-center gap-12 px-4 pb-14 pt-12 sm:px-6 lg:grid-cols-[1.02fr_0.98fr] lg:pb-20 lg:pt-16">
          <div className="rise-in">
            <div className="inline-flex items-center gap-2 rounded-full border border-forest/20 bg-paper px-3 py-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-forest pulse-dot" />
              <span className="mono-label !text-forest">AI community intelligence</span>
              <span className="h-3 w-px bg-line" />
              <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-ink/45">
                {stats.neighbours} neighbours · {stats.totalReports} reports
              </span>
            </div>

            <h1 className="display mt-6 text-[44px] sm:text-[58px] lg:text-[64px]">
              Small actions.
              <br />
              Smart intelligence.
              <br />
              <span className="accent-serif text-forest">Better tomorrow.</span>
            </h1>

            <p className="mt-6 max-w-lg text-[15px] leading-relaxed text-ink/65 sm:text-base">
              LifeLoop AI is a community problem-detection platform. Report what is broken, and our
              models identify the issue, catch duplicates, suggest priority and turn scattered
              complaints into one actionable thread.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link
                href="/report"
                className="group inline-flex items-center gap-2 rounded-full bg-forest px-5 py-3 text-[14px] font-semibold text-paper transition hover:bg-moss"
              >
                Report a problem
                <svg viewBox="0 0 24 24" className="h-4 w-4 transition group-hover:translate-x-0.5" fill="none" stroke="currentColor" strokeWidth={2} aria-hidden>
                  <path d="M5 12h14M13 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </Link>
              <Link
                href="/dashboard"
                className="inline-flex items-center gap-2 rounded-full border border-ink/15 bg-paper px-5 py-3 text-[14px] font-semibold text-ink transition hover:border-forest/40 hover:text-forest"
              >
                Explore the live dashboard
              </Link>
            </div>

            <div className="mt-9 grid max-w-md grid-cols-3 gap-4 border-t border-line pt-5">
              <div>
                <p className="display text-2xl">{stats.byCategory.length}</p>
                <p className="mt-1 text-[11px] leading-tight text-ink/50">problem categories detected</p>
              </div>
              <div>
                <p className="display text-2xl">{stats.resolutionRate}%</p>
                <p className="mt-1 text-[11px] leading-tight text-ink/50">reports resolved by community</p>
              </div>
              <div>
                <p className="display text-2xl">{stats.avgResolutionHours}h</p>
                <p className="mt-1 text-[11px] leading-tight text-ink/50">average time to resolution</p>
              </div>
            </div>
          </div>

          {/* HERO VISUAL */}
          <div className="relative rise-in">
            <div className="relative overflow-hidden rounded-[26px] border border-ink/10 bg-moss shadow-[0_40px_80px_-50px_rgba(11,58,44,0.8)]">
              <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
                <div className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-rose-400/80" />
                  <span className="h-2 w-2 rounded-full bg-amber-300/80" />
                  <span className="h-2 w-2 rounded-full bg-lime/80" />
                  <span className="ml-2 font-mono text-[9px] uppercase tracking-[0.16em] text-paper/50">
                    lifeloop · vision scanner
                  </span>
                </div>
                <span className="rounded-full border border-lime/30 bg-lime/10 px-2 py-0.5 font-mono text-[9px] uppercase tracking-[0.14em] text-lime">
                  live
                </span>
              </div>

              <div className="relative m-4 overflow-hidden rounded-2xl">
                <img
                  src={heroReport?.imageUrl ?? CATEGORIES[0].image}
                  alt="Reported community problem"
                  className="h-[236px] w-full object-cover sm:h-[264px]"
                />
                <div className="scan-frame absolute inset-0" />
                <div className="absolute inset-0 bg-gradient-to-t from-ink/85 via-ink/10 to-transparent" />
                <div className="absolute left-3 top-3 rounded-lg bg-ink/70 px-2.5 py-1.5 backdrop-blur">
                  <p className="font-mono text-[8px] uppercase tracking-[0.16em] text-lime">
                    inference complete · 0.8s
                  </p>
                </div>
                <div className="absolute inset-x-3 bottom-3">
                  <div className="flex items-end justify-between gap-3">
                    <div>
                      <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-paper/60">
                        predicted category
                      </p>
                      <p className="mt-1 flex items-center gap-2 text-[15px] font-semibold text-paper">
                        <CategoryGlyph category={heroReport?.category ?? "garbage"} className="h-4 w-4 text-lime" />
                        {categoryMeta(heroReport?.category ?? "garbage").label}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-paper/60">
                        confidence
                      </p>
                      <p className="display text-2xl text-lime">
                        {Math.round((heroReport?.aiConfidence ?? 0.94) * 100)}%
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-2 px-4 pb-4">
                <div className="flex items-center justify-between rounded-xl bg-white/[0.06] px-3 py-2.5">
                  <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-paper/50">
                    suggested priority
                  </span>
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-rose-400/15 px-2.5 py-1 text-[10px] font-semibold text-rose-200">
                    <span className="h-1.5 w-1.5 rounded-full bg-rose-300" />
                    High · {heroReport?.priorityScore ?? 82}/100
                  </span>
                </div>
                <div className="flex items-center justify-between rounded-xl bg-white/[0.06] px-3 py-2.5">
                  <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-paper/50">
                    duplicate intelligence
                  </span>
                  <span className="text-[10px] font-semibold text-lime">
                    {heroReport?.duplicateCount
                      ? `${heroReport.duplicateCount} similar reports grouped`
                      : "No duplicate found"}
                  </span>
                </div>
              </div>
            </div>

            <div className="float-slow absolute -left-3 bottom-16 hidden w-[210px] rounded-2xl border border-line bg-paper/95 p-3 shadow-xl backdrop-blur sm:block">
              <p className="mono-label !text-forest">Next best action</p>
              <p className="mt-1.5 text-[12px] font-semibold leading-snug text-ink">
                Verify the group instead of filing a new ticket
              </p>
              <div className="mt-2 flex items-center gap-1.5">
                <div className="h-1 w-10 rounded-full bg-forest" />
                <div className="h-1 w-6 rounded-full bg-forest/40" />
                <div className="h-1 w-3 rounded-full bg-forest/20" />
              </div>
            </div>

            <div className="float-slower absolute -right-2 -top-4 hidden items-center gap-2 rounded-full border border-line bg-paper px-3 py-2 shadow-lg sm:flex">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-lime text-moss">
                <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={2} aria-hidden>
                  <path d="M5 12.5 10 17l9-10" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </span>
              <span className="text-[11px] font-semibold text-ink">
                {stats.duplicatesGrouped} duplicates grouped
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* LIVE BAND */}
      <section className="border-b border-line bg-paper">
        <div className="mx-auto grid max-w-[1180px] grid-cols-2 divide-line px-4 sm:px-6 lg:grid-cols-4 lg:divide-x">
          {[
            { value: stats.totalReports, label: "Problems reported", hint: "across 8 neighbourhoods" },
            { value: stats.resolved, label: "Resolved & verified", hint: `${stats.resolutionRate}% resolution rate` },
            { value: stats.duplicatesGrouped, label: "Duplicates grouped", hint: "one thread, not five tickets" },
            { value: stats.impactPoints.toLocaleString(), label: "Green impact points", hint: "earned by residents" },
          ].map((item) => (
            <div key={item.label} className="px-1 py-5 lg:px-6">
              <p className="display text-[26px] sm:text-[30px]">{item.value}</p>
              <p className="mt-1 text-[11px] font-semibold uppercase tracking-[0.13em] text-ink/50">
                {item.label}
              </p>
              <p className="mt-1 text-[11px] text-ink/40">{item.hint}</p>
            </div>
          ))}
        </div>
      </section>

      {/* PIPELINE */}
      <section className="mx-auto max-w-[1180px] px-4 py-16 sm:px-6">
        <div className="flex flex-col justify-between gap-5 md:flex-row md:items-end">
          <div>
            <SectionLabel>One report, five intelligent steps</SectionLabel>
            <h2 className="display mt-3 max-w-xl text-[30px] sm:text-[40px]">
              From scattered complaints to <span className="accent-serif text-forest">one clear signal.</span>
            </h2>
          </div>
          <p className="max-w-sm text-[13px] leading-relaxed text-ink/55">
            Reporting apps collect complaints. LifeLoop AI reads them, organises them and keeps the
            whole community on the same page.
          </p>
        </div>

        <div className="mt-9 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {PIPELINE.map((item, index) => (
            <div
              key={item.step}
              className="group relative flex flex-col rounded-2xl border border-line bg-paper p-4 transition hover:border-forest/35"
            >
              <div className="flex items-center justify-between">
                <span className="font-mono text-[10px] tracking-[0.16em] text-forest">{item.step}</span>
                {index < PIPELINE.length - 1 && (
                  <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 text-ink/20" fill="none" stroke="currentColor" strokeWidth={2} aria-hidden>
                    <path d="M5 12h14M13 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                )}
              </div>
              <h3 className="mt-3 text-[14px] font-semibold tracking-[-0.01em]">{item.title}</h3>
              <p className="mt-1.5 text-[12px] leading-relaxed text-ink/55">{item.copy}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CATEGORIES */}
      <section className="border-y border-line bg-paper">
        <div className="mx-auto max-w-[1180px] px-4 py-16 sm:px-6">
          <div className="flex flex-col justify-between gap-5 md:flex-row md:items-end">
            <div>
              <SectionLabel>What the model can see</SectionLabel>
              <h2 className="display mt-3 max-w-lg text-[30px] sm:text-[40px]">
                Six everyday problems. <span className="accent-serif text-forest">One shared map.</span>
              </h2>
            </div>
            <p className="max-w-xs text-[12px] leading-relaxed text-ink/50">
              Classifications are suggestions. Every report can be corrected by a resident — the AI
              prediction stays in the audit trail.
            </p>
          </div>

          <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {CATEGORIES.map((category) => {
              const count = stats.byCategory.find((item) => item.category === category.id);
              return (
                <Link
                  key={category.id}
                  href={`/dashboard?category=${category.id}`}
                  className="hover-lift group flex overflow-hidden rounded-2xl border border-line bg-bone"
                >
                  <div className="relative w-[104px] shrink-0 overflow-hidden sm:w-[118px]">
                    <img
                      src={category.image}
                      alt={category.label}
                      className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                      loading="lazy"
                    />
                    <span className="absolute inset-0 bg-gradient-to-r from-transparent to-bone/30" />
                  </div>
                  <div className="min-w-0 flex-1 p-3.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="inline-flex h-6 w-6 items-center justify-center rounded-md bg-forest/10 text-forest">
                        <CategoryGlyph category={category.id} className="h-3.5 w-3.5" />
                      </span>
                      <span className="font-mono text-[9px] uppercase tracking-[0.12em] text-ink/40">
                        {count?.count ?? 0} reports
                      </span>
                    </div>
                    <h3 className="mt-2 text-[13px] font-semibold leading-snug">{category.label}</h3>
                    <p className="mt-1 line-clamp-2 text-[11px] leading-relaxed text-ink/50">
                      {category.blurb}
                    </p>
                    <p className="mt-2 flex items-center gap-1 text-[10px] font-medium text-forest">
                      {category.department}
                      <svg viewBox="0 0 24 24" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth={2} aria-hidden>
                        <path d="M5 12h14M13 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </p>
                  </div>
                </Link>
              );
            })}
          </div>
          <div className="mt-6 flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-line bg-bone px-4 py-3">
            <CategoryLegend />
            <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-ink/40">
              vision + multilingual text fusion
            </span>
          </div>
        </div>
      </section>

      {/* LIVE FEED */}
      <section className="mx-auto max-w-[1180px] px-4 py-16 sm:px-6">
        <div className="flex items-end justify-between gap-4">
          <div>
            <SectionLabel>Live community signal</SectionLabel>
            <h2 className="display mt-3 text-[30px] sm:text-[40px]">Needs attention now</h2>
          </div>
          <Link
            href="/dashboard"
            className="hidden items-center gap-1.5 text-[13px] font-semibold text-forest hover:underline sm:inline-flex"
          >
            Open dashboard
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2} aria-hidden>
              <path d="M5 12h14M13 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </Link>
        </div>
        <div className="mt-7 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {featured.map((report) => (
            <ReportCard key={report.id} report={report} />
          ))}
        </div>
        <Link
          href="/dashboard"
          className="mt-5 flex items-center justify-center gap-1.5 rounded-full border border-line bg-paper py-3 text-[13px] font-semibold text-forest sm:hidden"
        >
          Open dashboard
        </Link>
      </section>

      {/* DUPLICATE INTELLIGENCE */}
      <section className="mx-auto max-w-[1180px] px-4 pb-16 sm:px-6">
        <div className="overflow-hidden rounded-[26px] bg-moss text-paper">
          <div className="grid gap-10 p-6 sm:p-10 lg:grid-cols-[0.95fr_1.05fr] lg:items-center">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full border border-lime/25 bg-lime/10 px-3 py-1 font-mono text-[9px] uppercase tracking-[0.16em] text-lime">
                Signature feature
              </span>
              <h2 className="display mt-4 text-[30px] leading-[1.02] sm:text-[38px]">
                Five people report the same pothole.
                <span className="accent-serif text-lime"> LifeLoop counts one problem.</span>
              </h2>
              <p className="mt-4 max-w-md text-[13px] leading-relaxed text-paper/65">
                Similarity blends wording overlap, category agreement and how close the reports are.
                Teams get a single verified thread with every resident voice attached — not five
                duplicates to triage.
              </p>
              <ul className="mt-6 space-y-3">
                {[
                  "Text similarity + trigram matching on report wording",
                  "Geo-distance weighting within the same neighbourhood",
                  "A human always confirms the merge — nothing is deleted",
                ].map((item) => (
                  <li key={item} className="flex items-start gap-2.5 text-[12.5px] text-paper/75">
                    <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-lime text-moss">
                      <svg viewBox="0 0 24 24" className="h-2.5 w-2.5" fill="none" stroke="currentColor" strokeWidth={3} aria-hidden>
                        <path d="M5 12.5 10 17l9-10" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </span>
                    {item}
                  </li>
                ))}
              </ul>
              <Link
                href={`/reports/${grouped?.id ?? heroReport?.id ?? 1}`}
                className="mt-7 inline-flex items-center gap-2 rounded-full bg-lime px-4 py-2.5 text-[13px] font-semibold text-moss transition hover:bg-lime-soft"
              >
                See a grouped thread
                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2} aria-hidden>
                  <path d="M5 12h14M13 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </Link>
            </div>

            <div className="space-y-2.5">
              {[
                { ref: "LL-1024", name: "Aisha", text: "Bins overflowing at Temple Street market", sim: 96 },
                { ref: "LL-1027", name: "Marco", text: "Garbage pile near temple street bins", sim: 91 },
                { ref: "LL-1030", name: "Grace", text: "Waste dumped at the Old Town bus bay", sim: 84 },
              ].map((item, index) => (
                <div
                  key={item.ref}
                  className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.05] p-3"
                  style={{ marginLeft: `${index * 14}px` }}
                >
                  <span className="font-mono text-[9px] text-paper/40">{item.ref}</span>
                  <span className="flex-1 truncate text-[12px] text-paper/80">{item.text}</span>
                  <span className="rounded-full bg-lime/15 px-2 py-0.5 font-mono text-[9px] text-lime">
                    {item.sim}%
                  </span>
                </div>
              ))}
              <div className="flex items-center justify-between rounded-2xl border border-lime/30 bg-lime/10 p-4">
                <div className="flex items-center gap-3">
                  <div className="flex -space-x-2">
                    {leaders.slice(0, 3).map((leader) => (
                      <Avatar key={leader.id} name={leader.name} tone={leader.tone} size="sm" />
                    ))}
                  </div>
                  <div>
                    <p className="text-[12px] font-semibold text-lime">1 shared action thread</p>
                    <p className="text-[10px] text-paper/55">
                      {grouped?.duplicateCount ?? 2} duplicates grouped · {grouped?.upvotes ?? 34} residents supporting
                    </p>
                  </div>
                </div>
                <span className="hidden rounded-full bg-lime px-2.5 py-1 text-[10px] font-bold text-moss sm:inline">
                  grouped
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* HEATMAP + LEADERBOARD */}
      <section className="mx-auto max-w-[1180px] px-4 pb-16 sm:px-6">
        <div className="grid gap-4 lg:grid-cols-[1.15fr_0.85fr]">
          <div className="rounded-[24px] border border-line bg-paper p-5 sm:p-6">
            <div className="flex items-start justify-between">
              <div>
                <SectionLabel>Community heatmap</SectionLabel>
                <h3 className="display mt-2 text-[24px]">Where problems cluster</h3>
              </div>
              <Link href="/heatmap" className="text-[12px] font-semibold text-forest hover:underline">
                Open map →
              </Link>
            </div>
            <div className="relative mt-5 h-[230px] overflow-hidden rounded-2xl border border-line bg-bone">
              <div className="grid-paper absolute inset-0 opacity-80" />
              <svg viewBox="0 0 100 100" className="absolute inset-0 h-full w-full" aria-hidden>
                <path d="M0 68 C18 60 24 74 38 70 C55 65 62 82 82 74 C92 70 96 62 100 58 L100 100 L0 100 Z" fill="#cfe4d6" opacity="0.7" />
                <path d="M0 68 C18 60 24 74 38 70 C55 65 62 82 82 74 C92 70 96 62 100 58" stroke="#9fc4b0" strokeWidth="0.4" fill="none" />
                <rect x="6" y="10" width="18" height="14" rx="2" fill="#dfe7cf" />
                <rect x="48" y="6" width="16" height="12" rx="2" fill="#dfe7cf" />
                <rect x="70" y="42" width="18" height="14" rx="2" fill="#dfe7cf" />
                <path d="M4 40 H96M30 4 V76M66 4 V76" stroke="#0d1f18" strokeOpacity="0.08" strokeWidth="0.5" />
              </svg>
              {stats.byNeighbourhood.map((hood) => {
                const size = 5 + hood.total * 2.6;
                const intensity = hood.total > 4 ? "rgba(224,120,79,0.6)" : "rgba(20,99,73,0.45)";
                return (
                  <div
                    key={hood.id}
                    className="absolute -translate-x-1/2 -translate-y-1/2"
                    style={{ left: `${hood.x}%`, top: `${hood.y}%` }}
                  >
                    <span
                      className="block rounded-full blur-[2px]"
                      style={{ width: size, height: size, backgroundColor: intensity }}
                    />
                    <span
                      className="absolute left-1/2 top-1/2 h-2 w-2 -translate-x-1/2 -translate-y-1/2 rounded-full border border-paper bg-forest"
                    />
                    <span className="absolute left-1/2 top-full mt-1 hidden -translate-x-1/2 whitespace-nowrap rounded bg-paper px-1.5 py-0.5 text-[9px] font-medium text-ink/70 shadow-sm sm:block">
                      {hood.name} · {hood.total}
                    </span>
                  </div>
                );
              })}
              <div className="absolute bottom-2 left-2 rounded-lg bg-paper/90 px-2 py-1 font-mono text-[8px] uppercase tracking-[0.1em] text-ink/50">
                bubble size = open reports
              </div>
            </div>
          </div>

          <div className="rounded-[24px] border border-line bg-paper p-5 sm:p-6">
            <div className="flex items-start justify-between">
              <div>
                <SectionLabel>Green impact</SectionLabel>
                <h3 className="display mt-2 text-[24px]">Neighbours on a roll</h3>
              </div>
              <Link href="/impact" className="text-[12px] font-semibold text-forest hover:underline">
                Leaderboard →
              </Link>
            </div>
            <div className="mt-5 space-y-1">
              {leaders.slice(0, 5).map((leader, index) => (
                <div
                  key={leader.id}
                  className="flex items-center gap-3 rounded-xl px-2 py-2.5 transition hover:bg-bone"
                >
                  <span className="w-4 font-mono text-[11px] text-ink/35">
                    {String(index + 1).padStart(2, "0")}
                  </span>
                  <Avatar name={leader.name} tone={leader.tone} size="sm" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12.5px] font-semibold">{leader.name}</p>
                    <p className="text-[10px] text-ink/45">
                      {leader.neighbourhood} · {leader.reportsCount} reports
                    </p>
                  </div>
                  <span className="font-mono text-[11px] font-medium text-forest">{leader.points}</span>
                </div>
              ))}
            </div>
            <div className="mt-4 rounded-xl border border-dashed border-forest/25 bg-lime-soft/50 px-3 py-2.5 text-[11px] leading-relaxed text-forest">
              Points are earned for verified reports, confirmations and resolved issues — never for
              filing duplicates.
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-[1180px] px-4 pb-6 sm:px-6">
        <div className="relative overflow-hidden rounded-[26px] border border-forest/15 bg-lime px-6 py-10 sm:px-10">
          <div className="dot-paper absolute inset-0 opacity-20" />
          <div className="relative flex flex-col items-start justify-between gap-6 lg:flex-row lg:items-center">
            <div>
              <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-moss/60">
                We don&apos;t just want people to notice problems
              </p>
              <h2 className="display mt-2 max-w-xl text-[28px] leading-[1.03] text-moss sm:text-[38px]">
                We want technology to help communities take meaningful action.
              </h2>
            </div>
            <div className="flex flex-col gap-2 sm:flex-row">
              <Link
                href="/report"
                className="inline-flex items-center justify-center gap-2 rounded-full bg-moss px-5 py-3 text-[13px] font-semibold text-paper transition hover:bg-ink"
              >
                Report an issue
                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2} aria-hidden>
                  <path d="M5 12h14M13 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </Link>
              <Link
                href="/dashboard"
                className="inline-flex items-center justify-center rounded-full border border-moss/25 px-5 py-3 text-[13px] font-semibold text-moss transition hover:bg-moss/10"
              >
                View dashboard
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
