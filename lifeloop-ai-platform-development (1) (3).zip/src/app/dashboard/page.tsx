import Link from "next/link";
import DashboardClient from "@/components/DashboardClient";
import { SectionLabel, Stat } from "@/components/ui";
import { getAllReports, getLeaderboard, getPlatformStats } from "@/lib/data";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string; tab?: string }>;
}) {
  await ensureSeeded();
  const params = await searchParams;
  const [allReports, leaders] = await Promise.all([getAllReports(), getLeaderboard()]);
  const stats = await getPlatformStats(allReports, leaders);

  const peak = Math.max(1, ...stats.trend.map((day) => day.reported + day.resolved));

  return (
    <div className="mx-auto max-w-[1180px] px-4 py-8 sm:px-6 sm:py-10">
      <div className="flex flex-col justify-between gap-5 lg:flex-row lg:items-end">
        <div>
          <SectionLabel>Shared community dashboard</SectionLabel>
          <h1 className="display mt-3 text-[34px] sm:text-[46px]">
            Every report. <span className="accent-serif text-forest">One action trail.</span>
          </h1>
          <p className="mt-3 max-w-xl text-[13.5px] leading-relaxed text-ink/60">
            AI-classified community problems from eight neighbourhoods. Filter by category, urgency
            or duplicate group — then open a thread to verify, correct or track the fix.
          </p>
        </div>
        <div className="flex items-center gap-2 text-[11px]">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-line bg-paper px-3 py-2 font-mono uppercase tracking-[0.12em] text-ink/50">
            <span className="h-1.5 w-1.5 rounded-full bg-forest pulse-dot" />
            live data · postgres
          </span>
          <Link
            href="/heatmap"
            className="rounded-full border border-line bg-paper px-3 py-2 font-medium text-forest hover:border-forest/40"
          >
            View heatmap
          </Link>
        </div>
      </div>

      <div className="mt-7 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat value={stats.totalReports} label="Total reports" hint={`${stats.open} open right now`} />
        <Stat
          value={stats.resolved}
          label="Resolved"
          hint={`${stats.resolutionRate}% resolution rate`}
          tone="lime"
        />
        <Stat
          value={stats.highPriority}
          label="High priority open"
          hint="AI-suggested, community verified"
        />
        <Stat
          value={stats.duplicatesGrouped}
          label="Duplicates grouped"
          hint={`Avg. resolution ${stats.avgResolutionHours}h`}
          tone="dark"
        />
      </div>

      <div className="mt-3 grid gap-3 lg:grid-cols-[1.35fr_1fr]">
        <div className="rounded-2xl border border-line bg-paper p-4">
          <div className="flex items-end justify-between">
            <div>
              <p className="mono-label">14-day signal</p>
              <p className="mt-1 text-[13px] font-semibold">
                {stats.trend.reduce((sum, day) => sum + day.reported, 0)} reported ·{" "}
                {stats.trend.reduce((sum, day) => sum + day.resolved, 0)} resolved
              </p>
            </div>
            <div className="flex items-center gap-3 text-[10px] text-ink/45">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-1.5 w-4 rounded-full bg-forest" /> reported
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-1.5 w-4 rounded-full bg-lime" /> resolved
              </span>
            </div>
          </div>
          <div className="mt-3 flex h-20 items-end gap-[3px]">
            {stats.trend.map((day) => (
              <div key={day.date} className="group relative flex flex-1 flex-col items-center justify-end gap-[2px]">
                <div
                  className="w-full rounded-t-sm bg-forest/85 transition group-hover:bg-forest"
                  style={{ height: `${Math.max(2, (day.reported / peak) * 62)}px` }}
                />
                <div
                  className="w-full rounded-b-sm bg-lime"
                  style={{ height: `${Math.max(2, (day.resolved / peak) * 18)}px` }}
                />
                <span className="pointer-events-none absolute -top-6 z-10 hidden whitespace-nowrap rounded bg-ink px-1.5 py-1 text-[9px] text-paper group-hover:block">
                  {day.reported} in · {day.resolved} out
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-line bg-paper p-4">
          <p className="mono-label">Neighbourhood load</p>
          <div className="mt-3 space-y-2">
            {stats.byNeighbourhood
              .slice()
              .sort((a, b) => b.total - a.total)
              .slice(0, 4)
              .map((hood) => (
                <div key={hood.id} className="flex items-center gap-2.5">
                  <span className="w-24 shrink-0 truncate text-[11px] font-medium text-ink/70">
                    {hood.name}
                  </span>
                  <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-mist">
                    <div
                      className="h-full rounded-full bg-forest/80"
                      style={{ width: `${Math.min(100, (hood.total / stats.totalReports) * 190)}%` }}
                    />
                  </div>
                  <span className="w-8 text-right font-mono text-[10px] text-ink/45">{hood.total}</span>
                </div>
              ))}
          </div>
          <Link href="/heatmap" className="mt-3 inline-flex text-[11px] font-semibold text-forest hover:underline">
            Explore the hotspot map →
          </Link>
        </div>
      </div>

      <div className="mt-7">
        <DashboardClient
          reports={allReports}
          initialTab={params.tab ?? "all"}
          initialCategory={params.category ?? "all"}
        />
      </div>
    </div>
  );
}
