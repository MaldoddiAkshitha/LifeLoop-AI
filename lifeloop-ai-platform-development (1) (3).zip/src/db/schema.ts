import {
  boolean,
  doublePrecision,
  index,
  integer,
  jsonb,
  pgTable,
  real,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import type {
  AiSignals,
  CategoryId,
  DuplicateMatch,
  Priority,
  Recommendation,
  ReportStatus,
} from "@/lib/types";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  handle: text("handle").notNull().unique(),
  neighbourhood: text("neighbourhood").notNull(),
  role: text("role").notNull().default("Resident"),
  tone: text("tone").notNull().default("emerald"),
  points: integer("points").notNull().default(0),
  reportsCount: integer("reports_count").notNull().default(0),
  resolvedCount: integer("resolved_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const reports = pgTable(
  "reports",
  {
    id: serial("id").primaryKey(),
    reference: text("reference").notNull(),
    reporterId: integer("reporter_id").references(() => users.id, {
      onDelete: "set null",
    }),
    title: text("title").notNull(),
    description: text("description").notNull(),
    language: text("language").notNull().default("en"),
    category: text("category").$type<CategoryId>().notNull(),
    aiCategory: text("ai_category").$type<CategoryId>().notNull(),
    aiConfidence: real("ai_confidence").notNull().default(0.7),
    priority: text("priority").$type<Priority>().notNull().default("medium"),
    priorityScore: integer("priority_score").notNull().default(50),
    priorityReason: text("priority_reason").notNull().default(""),
    status: text("status").$type<ReportStatus>().notNull().default("open"),
    neighbourhood: text("neighbourhood").notNull(),
    address: text("address").notNull().default(""),
    lat: doublePrecision("lat").notNull(),
    lng: doublePrecision("lng").notNull(),
    imageUrl: text("image_url"),
    aiSummary: text("ai_summary").notNull().default(""),
    tags: jsonb("tags").$type<string[]>().notNull().default([]),
    recommendations: jsonb("recommendations")
      .$type<Recommendation[]>()
      .notNull()
      .default([]),
    signals: jsonb("signals").$type<AiSignals | null>(),
    duplicateCandidates: jsonb("duplicate_candidates")
      .$type<DuplicateMatch[]>()
      .notNull()
      .default([]),
    responsibleDepartment: text("responsible_department").notNull().default(""),
    expectedResponse: text("expected_response").notNull().default(""),
    duplicateOfId: integer("duplicate_of_id"),
    duplicateCount: integer("duplicate_count").notNull().default(0),
    upvotes: integer("upvotes").notNull().default(0),
    verifications: integer("verifications").notNull().default(0),
    categoryCorrected: boolean("category_corrected").notNull().default(false),
    modelVersion: text("model_version").notNull().default("lifeloop-vision-2.1"),
    impactPoints: integer("impact_points").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
    resolvedAt: timestamp("resolved_at", { withTimezone: true }),
  },
  (table) => [
    uniqueIndex("reports_reference_idx").on(table.reference),
    index("reports_status_idx").on(table.status),
    index("reports_category_idx").on(table.category),
  ],
);

export const reportUpdates = pgTable(
  "report_updates",
  {
    id: serial("id").primaryKey(),
    reportId: integer("report_id")
      .notNull()
      .references(() => reports.id, { onDelete: "cascade" }),
    userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
    kind: text("kind").notNull().default("note"),
    fromStatus: text("from_status"),
    toStatus: text("to_status"),
    note: text("note").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("report_updates_report_idx").on(table.reportId)],
);

export const reportVotes = pgTable(
  "report_votes",
  {
    id: serial("id").primaryKey(),
    reportId: integer("report_id")
      .notNull()
      .references(() => reports.id, { onDelete: "cascade" }),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    kind: text("kind").notNull().default("upvote"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("report_votes_unique_idx").on(table.reportId, table.userId, table.kind),
  ],
);
