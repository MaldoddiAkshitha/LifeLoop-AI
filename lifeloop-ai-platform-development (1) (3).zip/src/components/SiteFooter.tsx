import Link from "next/link";
import { Logo } from "@/components/ui";

export default function SiteFooter() {
  return (
    <footer className="mt-16 border-t border-line bg-paper">
      <div className="mx-auto grid max-w-[1180px] gap-10 px-4 py-12 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
        <div>
          <Logo />
          <p className="mt-4 max-w-xs text-[13px] leading-relaxed text-ink/60">
            A community problem-detection platform. Observe what is broken, analyse it with AI, and
            improve it together.
          </p>
          <div className="mt-5 inline-flex items-center gap-2 rounded-full border border-line bg-bone px-3 py-1.5 font-mono text-[9px] uppercase tracking-[0.16em] text-ink/50">
            <span className="h-1.5 w-1.5 rounded-full bg-forest pulse-dot" />
            Model lifeloop-vision-2.1
          </div>
        </div>

        <div>
          <p className="mono-label">Platform</p>
          <ul className="mt-3 space-y-2 text-[13px] text-ink/65">
            <li>
              <Link href="/dashboard" className="hover:text-forest">
                Community dashboard
              </Link>
            </li>
            <li>
              <Link href="/report" className="hover:text-forest">
                Report an issue
              </Link>
            </li>
            <li>
              <Link href="/heatmap" className="hover:text-forest">
                Problem heatmap
              </Link>
            </li>
            <li>
              <Link href="/impact" className="hover:text-forest">
                Green impact points
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <p className="mono-label">Intelligence</p>
          <ul className="mt-3 space-y-2 text-[13px] text-ink/65">
            <li>Vision classifier</li>
            <li>Multilingual text model</li>
            <li>Duplicate similarity</li>
            <li>Priority recommendations</li>
          </ul>
        </div>

        <div className="rounded-2xl border border-line bg-bone p-4">
          <p className="mono-label">Responsible AI note</p>
          <p className="mt-2 text-[12px] leading-relaxed text-ink/60">
            Predictions are suggestions, not verified facts. Any resident can correct a category or
            priority, and every correction is logged.
          </p>
          <Link
            href="/dashboard?tab=duplicates"
            className="mt-3 inline-flex items-center gap-1 text-[12px] font-semibold text-forest hover:underline"
          >
            See how grouping works →
          </Link>
        </div>
      </div>

      <div className="border-t border-line">
        <div className="mx-auto flex max-w-[1180px] flex-col gap-2 px-4 py-5 text-[11px] text-ink/45 sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <p>LifeLoop AI · Small actions. Smart intelligence. Better tomorrow.</p>
          <p className="font-mono uppercase tracking-[0.14em]">
            Prototype data · Not an official municipal channel
          </p>
        </div>
      </div>
    </footer>
  );
}
