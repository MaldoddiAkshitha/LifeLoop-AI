import Link from "next/link";
import type { ReactNode } from "react";
import {
  CATEGORIES,
  PRIORITY_META,
  STATUS_META,
  categoryMeta,
  type CategoryId,
  type Priority,
  type ReportStatus,
} from "@/lib/types";

export function CategoryGlyph({
  category,
  className = "h-4 w-4",
}: {
  category: CategoryId | string;
  className?: string;
}) {
  const common = {
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.6,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  };
  switch (category) {
    case "garbage":
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden {...common}>
          <path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13" />
          <path d="M10 11v5M14 11v5" />
        </svg>
      );
    case "water":
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden {...common}>
          <path d="M12 3c3.2 4 5.5 6.6 5.5 9.5A5.5 5.5 0 0 1 12 18a5.5 5.5 0 0 1-5.5-5.5C6.5 9.6 8.8 7 12 3Z" />
          <path d="M9.5 13a2.5 2.5 0 0 0 2.5 2.5" />
        </svg>
      );
    case "roads":
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden {...common}>
          <path d="M7 3 4 21M17 3l3 18M12 4v3M12 11v3M12 18v3" />
        </svg>
      );
    case "lighting":
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden {...common}>
          <path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9V15h7v-1.1A6 6 0 0 0 12 3Z" />
        </svg>
      );
    case "food":
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden {...common}>
          <path d="M4 12h16a8 8 0 0 1-16 0ZM12 12V8M9 4c0 1.5 1.5 2 1.5 3.5M14 6c0 1.5 1.5 2 1.5 3.5" />
        </svg>
      );
    default:
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden {...common}>
          <path d="M14.5 4.5a3.5 3.5 0 0 1 5 5L17 12M9.5 19.5a3.5 3.5 0 0 1-5-5L7 12" />
          <path d="m8 9 7 7M5 21l3-3M19 3l-3 3" />
        </svg>
      );
  }
}

export function CategoryChip({
  category,
  size = "sm",
}: {
  category: CategoryId | string;
  size?: "sm" | "md";
}) {
  const meta = categoryMeta(category);
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border border-line bg-white/70 font-medium text-ink/80 ${
        size === "sm" ? "px-2.5 py-1 text-[11px]" : "px-3 py-1.5 text-xs"
      }`}
    >
      <CategoryGlyph category={meta.id} className="h-3.5 w-3.5" />
      {meta.short}
    </span>
  );
}

export function StatusBadge({ status }: { status: ReportStatus }) {
  const meta = STATUS_META[status];
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-semibold ${meta.className}`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${meta.dot}`} />
      {meta.label}
    </span>
  );
}

export function PriorityBadge({
  priority,
  score,
}: {
  priority: Priority;
  score?: number;
}) {
  const meta = PRIORITY_META[priority];
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-semibold ${meta.className}`}
    >
      <svg viewBox="0 0 24 24" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth={2.2} aria-hidden>
        <path d="M12 4v9M12 17.5v.5" strokeLinecap="round" />
      </svg>
      {priority}
      {typeof score === "number" ? <span className="opacity-60">· {score}</span> : null}
    </span>
  );
}

const TONES: Record<string, string> = {
  emerald: "bg-emerald-700 text-lime",
  sky: "bg-sky-800 text-sky-100",
  violet: "bg-violet-800 text-violet-100",
  amber: "bg-amber-700 text-amber-50",
  rose: "bg-rose-800 text-rose-100",
  teal: "bg-teal-800 text-teal-100",
  lime: "bg-lime-300 text-emerald-900",
  orange: "bg-orange-700 text-orange-50",
};

export function Avatar({
  name,
  tone = "emerald",
  size = "md",
}: {
  name: string;
  tone?: string | null;
  size?: "sm" | "md" | "lg";
}) {
  const initials = name
    .split(" ")
    .map((part) => part[0])
    .filter(Boolean)
    .slice(0, 2)
    .join("")
    .toUpperCase();
  const dims = size === "sm" ? "h-7 w-7 text-[10px]" : size === "lg" ? "h-12 w-12 text-sm" : "h-9 w-9 text-xs";
  return (
    <span
      className={`inline-flex shrink-0 items-center justify-center rounded-full font-semibold ${dims} ${
        TONES[tone ?? "emerald"] ?? TONES.emerald
      }`}
      aria-hidden
    >
      {initials}
    </span>
  );
}

export function ConfidenceMeter({
  value,
  label = "AI confidence",
  compact = false,
}: {
  value: number;
  label?: string;
  compact?: boolean;
}) {
  const pct = Math.round(value * 100);
  return (
    <div className={compact ? "w-full" : "w-full space-y-1.5"}>
      <div className="flex items-center justify-between">
        <span className="mono-label">{label}</span>
        <span className="font-mono text-[11px] font-medium text-ink">{pct}%</span>
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-mist">
        <div
          className="h-full rounded-full bg-gradient-to-r from-forest to-leaf"
          style={{ width: `${Math.max(4, Math.min(100, pct))}%` }}
        />
      </div>
    </div>
  );
}

export function SectionLabel({ children }: { children: ReactNode }) {
  return (
    <div className="flex items-center gap-2.5">
      <span className="h-1.5 w-1.5 rounded-full bg-forest" />
      <span className="mono-label">{children}</span>
    </div>
  );
}

export function Stat({
  value,
  label,
  hint,
  tone = "light",
}: {
  value: ReactNode;
  label: string;
  hint?: string;
  tone?: "light" | "dark" | "lime";
}) {
  const styles =
    tone === "dark"
      ? "bg-moss text-paper border-moss"
      : tone === "lime"
        ? "bg-lime text-moss border-lime"
        : "bg-paper text-ink border-line";
  return (
    <div className={`rounded-2xl border p-4 sm:p-5 ${styles}`}>
      <div className="display text-2xl sm:text-3xl">{value}</div>
      <div
        className={`mt-1.5 text-[11px] font-semibold uppercase tracking-[0.14em] ${
          tone === "dark" ? "text-paper/60" : tone === "lime" ? "text-moss/70" : "text-ink/45"
        }`}
      >
        {label}
      </div>
      {hint ? (
        <div className={`mt-1 text-xs ${tone === "dark" ? "text-paper/50" : "text-ink/50"}`}>{hint}</div>
      ) : null}
    </div>
  );
}

export function CategoryLegend() {
  return (
    <div className="flex flex-wrap gap-x-4 gap-y-2">
      {CATEGORIES.map((category) => (
        <span key={category.id} className="inline-flex items-center gap-1.5 text-[11px] text-ink/60">
          <CategoryGlyph category={category.id} className="h-3.5 w-3.5" />
          {category.short}
        </span>
      ))}
    </div>
  );
}

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <Link href="/" className="group flex items-center gap-2.5">
      <span className="relative flex h-9 w-9 items-center justify-center rounded-[11px] bg-moss text-lime">
        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={1.8} aria-hidden>
          <path
            d="M7.5 15.5a4 4 0 0 1 .6-7.95 5.2 5.2 0 0 1 9.6 1.2 3.6 3.6 0 0 1-.7 7.15H8.5"
            strokeLinecap="round"
          />
          <path d="M10.5 12.6 12 14.2l3-3.2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-lime ring-2 ring-bone" />
      </span>
      {!compact && (
        <span className="flex flex-col leading-none">
          <span className="text-[15px] font-extrabold tracking-tight text-ink">
            LifeLoop <span className="text-forest">AI</span>
          </span>
          <span className="mt-1 font-mono text-[8px] uppercase tracking-[0.2em] text-ink/45">
            Observe · Analyse · Improve
          </span>
        </span>
      )}
    </Link>
  );
}
