"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { CategoryGlyph, PriorityBadge, StatusBadge } from "@/components/ui";
import {
  CATEGORIES,
  NEIGHBOURHOODS,
  categoryMeta,
  type CategoryId,
  type ReportRecord,
} from "@/lib/types";

const CATEGORY_COLOR: Record<CategoryId, string> = {
  garbage: "#146349",
  water: "#0e7490",
  roads: "#b45309",
  lighting: "#4338ca",
  food: "#be123c",
  infrastructure: "#0f766e",
};

export default function HeatMapClient({ reports }: { reports: ReportRecord[] }) {
  const [category, setCategory] = useState<string>("all");
  const [onlyOpen, setOnlyOpen] = useState(true);
  const [selected, setSelected] = useState<string>(NEIGHBOURHOODS[0].name);

  const filtered = useMemo(
    () =>
      reports.filter((report) => {
        if (category !== "all" && report.category !== category) return false;
        if (onlyOpen && report.status === "resolved") return false;
        return true;
      }),
    [reports, category, onlyOpen],
  );

  const zones = useMemo(
    () =>
      NEIGHBOURHOODS.map((hood) => {
        const matches = filtered.filter(
          (report) => report.neighbourhood.toLowerCase() === hood.name.toLowerCase(),
        );
        const counts: Record<string, number> = {};
        matches.forEach((report) => {
          counts[report.category] = (counts[report.category] ?? 0) + 1;
        });
        const dominant = (Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] ??
          "garbage") as CategoryId;
        return {
          ...hood,
          total: matches.length,
          open: matches.filter((report) => report.status !== "resolved").length,
          resolved: matches.filter((report) => report.status === "resolved").length,
          high: matches.filter((report) => report.priority === "high" && report.status !== "resolved")
            .length,
          counts,
          dominant,
          reports: matches,
        };
      }),
    [filtered],
  );

  const maxTotal = Math.max(1, ...zones.map((zone) => zone.total));
  const active = zones.find((zone) => zone.name === selected) ?? zones[0];
  const hotspots = [...zones].sort((a, b) => b.total - a.total);
  const worst = [...zones].sort((a, b) => b.high - a.high)[0];

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            onClick={() => setCategory("all")}
            className={`rounded-full px-3 py-1.5 text-[11.5px] font-medium transition ${
              category === "all" ? "bg-ink text-paper" : "bg-paper text-ink/55 hover:text-ink"
            }`}
          >
            All categories
          </button>
          {CATEGORIES.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setCategory(category === item.id ? "all" : item.id)}
              className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1.5 text-[11.5px] font-medium transition ${
                category === item.id ? "bg-ink text-paper" : "bg-paper text-ink/55 hover:text-ink"
              }`}
            >
              <CategoryGlyph category={item.id} className="h-3 w-3" />
              {item.short}
            </button>
          ))}
        </div>
        <label className="inline-flex cursor-pointer items-center gap-2 rounded-full border border-line bg-paper px-3 py-1.5 text-[11px] font-medium text-ink/60">
          <input
            type="checkbox"
            checked={onlyOpen}
            onChange={(event) => setOnlyOpen(event.target.checked)}
            className="h-3.5 w-3.5 accent-[#146349]"
          />
          Unresolved only
        </label>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-[1.35fr_0.65fr]">
        <div className="relative overflow-hidden rounded-[24px] border border-line bg-paper">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <div>
              <p className="mono-label">Meridian community map</p>
              <p className="mt-0.5 text-[11px] text-ink/45">
                Bubble size = active reports · click a neighbourhood
              </p>
            </div>
            <div className="hidden items-center gap-3 text-[9.5px] text-ink/45 sm:flex">
              <span className="inline-flex items-center gap-1">
                <span className="h-2 w-2 rounded-full bg-forest" /> low
              </span>
              <span className="inline-flex items-center gap-1">
                <span className="h-3 w-3 rounded-full bg-clay/70" /> hotspot
              </span>
            </div>
          </div>

          <div className="relative h-[400px] w-full bg-bone">
            <div className="grid-paper absolute inset-0 opacity-70" />
            <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 h-full w-full" aria-hidden>
              <path
                d="M-2 62 C12 54 20 66 32 64 C46 62 52 76 66 72 C78 68 84 58 102 54 L102 104 L-2 104 Z"
                fill="#d4e7da"
              />
              <path
                d="M-2 62 C12 54 20 66 32 64 C46 62 52 76 66 72 C78 68 84 58 102 54"
                stroke="#a7c9b5"
                strokeWidth="0.5"
                fill="none"
              />
              <rect x="4" y="6" width="22" height="18" rx="3" fill="#e7eed8" />
              <rect x="44" y="4" width="20" height="15" rx="3" fill="#e7eed8" />
              <rect x="68" y="38" width="24" height="18" rx="3" fill="#e7eed8" />
              <rect x="10" y="70" width="22" height="18" rx="3" fill="#e7eed8" />
              <path d="M2 44 H98M32 2 V78M66 2 V92M14 2 V44M88 44 V92" stroke="#0d1f18" strokeOpacity="0.09" strokeWidth="0.7" />
            </svg>

            {zones.map((zone) => {
              const size = 26 + (zone.total / maxTotal) * 56;
              const color = CATEGORY_COLOR[zone.dominant];
              const isActive = active?.name === zone.name;
              return (
                <button
                  key={zone.id}
                  type="button"
                  onClick={() => setSelected(zone.name)}
                  className="absolute -translate-x-1/2 -translate-y-1/2 transition hover:scale-105"
                  style={{ left: `${zone.x}%`, top: `${zone.y}%` }}
                  aria-label={`${zone.name}: ${zone.total} reports`}
                >
                  <span
                    className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full blur-md"
                    style={{
                      width: size * 1.5,
                      height: size * 1.5,
                      backgroundColor: color,
                      opacity: zone.total ? 0.2 : 0.05,
                    }}
                  />
                  <span
                    className={`relative flex items-center justify-center rounded-full border-2 font-mono text-[10px] font-semibold text-white shadow-sm transition ${
                      isActive ? "border-ink ring-2 ring-lime/70" : "border-paper"
                    }`}
                    style={{
                      width: size,
                      height: size,
                      backgroundColor: zone.total ? color : "#cbd5c5",
                      opacity: zone.total ? 0.9 : 0.5,
                    }}
                  >
                    {zone.total}
                  </span>
                  <span className="absolute left-1/2 top-full mt-1 -translate-x-1/2 whitespace-nowrap rounded bg-paper/95 px-1.5 py-0.5 text-[9px] font-medium text-ink/65 shadow-sm">
                    {zone.name}
                  </span>
                </button>
              );
            })}

            <div className="absolute bottom-2 left-2 max-w-[180px] rounded-lg border border-line bg-paper/95 px-2.5 py-2 text-[9.5px] leading-relaxed text-ink/50">
              <span className="font-semibold text-ink/70">{active?.name}</span> · {active?.total}{" "}
              reports · {active?.high} high priority
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <div className="rounded-[22px] border border-line bg-paper p-4">
            <div className="flex items-center justify-between">
              <p className="mono-label">Neighbourhood detail</p>
              <span className="rounded-full border border-line bg-bone px-2 py-0.5 font-mono text-[9px] text-ink/45">
                {active?.total ?? 0} filtered
              </span>
            </div>
            <h3 className="display mt-1.5 text-[22px]">{active?.name}</h3>
            <div className="mt-2.5 grid grid-cols-3 gap-1.5">
              {[
                { label: "Open", value: active?.open ?? 0 },
                { label: "Resolved", value: active?.resolved ?? 0 },
                { label: "High", value: active?.high ?? 0 },
              ].map((item) => (
                <div key={item.label} className="rounded-lg bg-bone/60 px-2 py-1.5 text-center">
                  <p className="display text-lg">{item.value}</p>
                  <p className="text-[9px] uppercase tracking-[0.1em] text-ink/40">{item.label}</p>
                </div>
              ))}
            </div>

            <div className="mt-3 space-y-1.5">
              {Object.entries(active?.counts ?? {})
                .sort((a, b) => b[1] - a[1])
                .map(([key, value]) => (
                  <div key={key} className="flex items-center gap-2">
                    <span className="w-20 shrink-0 truncate text-[10.5px] text-ink/60">
                      {categoryMeta(key).short}
                    </span>
                    <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-mist">
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${Math.min(100, (value / Math.max(1, active?.total ?? 1)) * 100)}%`,
                          backgroundColor: CATEGORY_COLOR[key as CategoryId],
                        }}
                      />
                    </div>
                    <span className="w-4 text-right font-mono text-[9px] text-ink/40">{value}</span>
                  </div>
                ))}
              {(active?.total ?? 0) === 0 && (
                <p className="rounded-lg bg-mist/50 px-2.5 py-2 text-[10.5px] text-ink/45">
                  No matching reports in this view.
                </p>
              )}
            </div>

            <div className="mt-3 space-y-1.5">
              {(active?.reports ?? []).slice(0, 3).map((report) => (
                <Link
                  key={report.id}
                  href={`/reports/${report.id}`}
                  className="block rounded-xl border border-line bg-bone/40 px-2.5 py-2 transition hover:border-forest/35"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-[8.5px] text-ink/40">{report.reference}</span>
                    <StatusBadge status={report.status} />
                  </div>
                  <p className="mt-1 line-clamp-2 text-[11px] font-medium leading-snug text-ink/80">
                    {report.title}
                  </p>
                </Link>
              ))}
            </div>
          </div>

          <div className="rounded-[22px] border border-forest/25 bg-lime-soft/50 p-4">
            <p className="mono-label !text-forest">AI hotspot insight</p>
            <p className="mt-1.5 text-[11.5px] leading-relaxed text-forest/85">
              {worst && worst.high > 0 ? (
                <>
                  <span className="font-semibold">{worst.name}</span> carries the highest unresolved
                  risk load ({worst.high} high-priority {worst.high === 1 ? "report" : "reports"}).
                  Cluster a single inspection visit instead of sending separate crews.
                </>
              ) : (
                "No unresolved high-priority clusters in the current view. Nice work, community."
              )}
            </p>
            <p className="mt-1.5 text-[10px] text-forest/60">
              Insight derives from report density and priority scores — a planning hint, not a
              decision.
            </p>
          </div>
        </div>
      </div>

      <div className="mt-4 rounded-[22px] border border-line bg-paper p-4">
        <div className="flex items-center justify-between">
          <p className="mono-label">Hotspot ranking</p>
          <span className="font-mono text-[9px] uppercase tracking-[0.1em] text-ink/35">
            active reports · {onlyOpen ? "unresolved" : "all time"}
          </span>
        </div>
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {hotspots.map((zone, index) => (
            <button
              key={zone.id}
              type="button"
              onClick={() => setSelected(zone.name)}
              className={`flex items-center gap-3 rounded-xl border px-3 py-2.5 text-left transition ${
                active?.name === zone.name
                  ? "border-forest/40 bg-lime-soft/40"
                  : "border-line bg-bone/40 hover:border-forest/25"
              }`}
            >
              <span className="font-mono text-[10px] text-ink/35">{String(index + 1).padStart(2, "0")}</span>
              <span className="min-w-0 flex-1">
                <span className="block text-[12px] font-semibold text-ink">{zone.name}</span>
                <span className="block text-[10px] text-ink/45">
                  {zone.open} open · {zone.resolved} resolved
                </span>
              </span>
              <div className="flex items-center gap-1">
                {zone.high > 0 && (
                  <span className="rounded-full bg-rose-50 px-1.5 py-0.5 font-mono text-[9px] font-semibold text-rose-700">
                    {zone.high} high
                  </span>
                )}
                <span className="rounded-full bg-forest px-2 py-0.5 font-mono text-[9px] font-semibold text-lime">
                  {zone.total}
                </span>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="mt-4 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-line bg-mist/50 px-4 py-3">
        <p className="text-[11px] text-ink/55">
          Duplicate threads are counted once, so a popular issue does not inflate the hotspot.
        </p>
        <Link href="/dashboard?tab=duplicates" className="text-[11px] font-semibold text-forest hover:underline">
          Review grouped reports →
        </Link>
      </div>
    </div>
  );
}
