"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import ReportCard from "@/components/ReportCard";
import { CategoryGlyph, StatusBadge } from "@/components/ui";
import {
  CATEGORIES,
  type CategoryId,
  type ReportRecord,
  type ReportStatus,
} from "@/lib/types";

type Props = {
  reports: ReportRecord[];
  initialTab: string;
  initialCategory: string;
};

const STATUS_OPTIONS: { value: "all" | ReportStatus; label: string }[] = [
  { value: "all", label: "Any status" },
  { value: "open", label: "Open" },
  { value: "in_progress", label: "In progress" },
  { value: "resolved", label: "Resolved" },
];

const SORTS = [
  { value: "newest", label: "Newest first" },
  { value: "priority", label: "Highest priority" },
  { value: "support", label: "Most supported" },
  { value: "confidence", label: "Model confidence" },
];

const CATEGORY_TONE: Record<string, string> = {
  garbage: "bg-emerald-100 text-emerald-800",
  water: "bg-sky-100 text-sky-800",
  roads: "bg-amber-100 text-amber-900",
  lighting: "bg-indigo-100 text-indigo-800",
  food: "bg-rose-100 text-rose-800",
  infrastructure: "bg-teal-100 text-teal-800",
};

export default function DashboardClient({ reports, initialTab, initialCategory }: Props) {
  const [tab, setTab] = useState(initialTab === "duplicates" ? "duplicates" : "all");
  const [category, setCategory] = useState<string>(initialCategory || "all");
  const [status, setStatus] = useState<"all" | ReportStatus>("all");
  const [sort, setSort] = useState("newest");
  const [search, setSearch] = useState("");
  const [onlyGrouped, setOnlyGrouped] = useState(false);

  const base = useMemo(() => {
    return reports.filter((report) => {
      if (tab === "attention" && !(report.status !== "resolved" && report.priority === "high")) {
        return false;
      }
      if (tab === "duplicates" && report.duplicateCount === 0) return false;
      if (category !== "all" && report.category !== category) return false;
      if (status !== "all" && report.status !== status) return false;
      if (onlyGrouped && report.duplicateCount === 0) return false;
      if (search.trim()) {
        const needle = search.toLowerCase();
        const haystack = `${report.title} ${report.description} ${report.neighbourhood} ${report.address} ${report.reference} ${report.tags.join(" ")}`.toLowerCase();
        if (!haystack.includes(needle)) return false;
      }
      return true;
    });
  }, [reports, tab, category, status, onlyGrouped, search]);

  const filtered = useMemo(() => {
    const copy = [...base];
    switch (sort) {
      case "priority":
        copy.sort((a, b) => b.priorityScore - a.priorityScore);
        break;
      case "support":
        copy.sort((a, b) => b.upvotes + b.verifications - (a.upvotes + a.verifications));
        break;
      case "confidence":
        copy.sort((a, b) => b.aiConfidence - a.aiConfidence);
        break;
      default:
        copy.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }
    return copy;
  }, [base, sort]);

  const counts = useMemo(
    () => ({
      all: reports.length,
      attention: reports.filter((r) => r.status !== "resolved" && r.priority === "high").length,
      duplicates: reports.filter((r) => r.duplicateCount > 0).length,
    }),
    [reports],
  );

  const categoryCounts = useMemo(() => {
    const map: Record<string, number> = {};
    reports.forEach((report) => {
      map[report.category] = (map[report.category] ?? 0) + 1;
    });
    return map;
  }, [reports]);

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5">
          {[
            { id: "all", label: "All reports", count: counts.all },
            { id: "attention", label: "Needs attention", count: counts.attention },
            { id: "duplicates", label: "Duplicate threads", count: counts.duplicates },
          ].map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setTab(item.id as typeof tab)}
              className={`inline-flex items-center gap-2 rounded-full border px-3.5 py-2 text-[12.5px] font-medium transition ${
                tab === item.id
                  ? "border-moss bg-moss text-paper"
                  : "border-line bg-paper text-ink/60 hover:border-forest/35 hover:text-ink"
              }`}
            >
              {item.label}
              <span
                className={`rounded-full px-1.5 py-0.5 font-mono text-[9px] ${
                  tab === item.id ? "bg-white/15 text-lime" : "bg-mist text-ink/50"
                }`}
              >
                {item.count}
              </span>
            </button>
          ))}
        </div>
        <Link
          href="/report"
          className="inline-flex items-center gap-1.5 rounded-full bg-forest px-4 py-2 text-[12.5px] font-semibold text-paper hover:bg-moss"
        >
          <span className="text-base leading-none">+</span> Report an issue
        </Link>
      </div>

      <div className="mt-4 rounded-2xl border border-line bg-paper p-3">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
          <div className="relative flex-1">
            <svg viewBox="0 0 24 24" className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink/35" fill="none" stroke="currentColor" strokeWidth={1.8} aria-hidden>
              <circle cx="11" cy="11" r="6.5" />
              <path d="m16 16 4 4" strokeLinecap="round" />
            </svg>
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search by issue, reference, street or neighbourhood…"
              className="w-full rounded-xl border border-line bg-bone/60 py-2.5 pl-9 pr-3 text-[12.5px] text-ink placeholder:text-ink/35 focus:border-forest/50 focus:bg-white focus:outline-none"
            />
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <select
              value={status}
              onChange={(event) => setStatus(event.target.value as typeof status)}
              className="rounded-xl border border-line bg-bone/60 px-3 py-2.5 text-[12px] font-medium text-ink/70 focus:border-forest/50 focus:outline-none"
            >
              {STATUS_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
            <select
              value={sort}
              onChange={(event) => setSort(event.target.value)}
              className="rounded-xl border border-line bg-bone/60 px-3 py-2.5 text-[12px] font-medium text-ink/70 focus:border-forest/50 focus:outline-none"
            >
              {SORTS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
            <button
              type="button"
              onClick={() => setOnlyGrouped((value) => !value)}
              className={`inline-flex items-center gap-1.5 rounded-xl border px-3 py-2.5 text-[12px] font-medium transition ${
                onlyGrouped
                  ? "border-forest bg-lime-soft text-forest"
                  : "border-line bg-bone/60 text-ink/60 hover:text-ink"
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={1.8} aria-hidden>
                <circle cx="9" cy="9" r="2.5" />
                <circle cx="16" cy="15" r="2.5" />
                <path d="M11 11l3 2" strokeLinecap="round" />
              </svg>
              Grouped only
            </button>
          </div>
        </div>

        <div className="mt-3 flex items-center gap-1.5 overflow-x-auto no-scrollbar border-t border-line pt-3">
          <button
            type="button"
            onClick={() => setCategory("all")}
            className={`shrink-0 rounded-full px-2.5 py-1 text-[11px] font-medium transition ${
              category === "all" ? "bg-ink text-paper" : "bg-mist/70 text-ink/55 hover:text-ink"
            }`}
          >
            All categories
          </button>
          {CATEGORIES.map((option) => (
            <button
              key={option.id}
              type="button"
              onClick={() => setCategory(category === option.id ? "all" : option.id)}
              className={`inline-flex shrink-0 items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-medium transition ${
                category === option.id
                  ? "bg-ink text-paper"
                  : "bg-mist/70 text-ink/55 hover:text-ink"
              }`}
            >
              <CategoryGlyph category={option.id} className="h-3 w-3" />
              {option.short}
              <span className={category === option.id ? "text-lime" : "text-ink/35"}>
                {categoryCounts[option.id] ?? 0}
              </span>
            </button>
          ))}
        </div>
      </div>

      <div className="mt-5 flex items-center justify-between">
        <p className="text-[12px] text-ink/50">
          Showing <span className="font-semibold text-ink">{filtered.length}</span> of {reports.length}{" "}
          reports
        </p>
        {tab === "duplicates" && (
          <p className="hidden items-center gap-1.5 text-[11px] text-forest sm:flex">
            <span className="h-1.5 w-1.5 rounded-full bg-forest" />
            One thread per real problem — duplicates stay attached to it
          </p>
        )}
      </div>

      {filtered.length === 0 ? (
        <div className="mt-4 rounded-2xl border border-dashed border-line bg-paper px-6 py-16 text-center">
          <p className="display text-xl">No reports match those filters</p>
          <p className="mx-auto mt-2 max-w-sm text-[13px] text-ink/50">
            Try clearing the search or category filter. New community reports appear here within
            seconds of submission.
          </p>
          <button
            type="button"
            onClick={() => {
              setSearch("");
              setCategory("all");
              setStatus("all");
              setOnlyGrouped(false);
              setTab("all");
            }}
            className="mt-4 rounded-full border border-forest/30 px-4 py-2 text-[12px] font-semibold text-forest"
          >
            Reset filters
          </button>
        </div>
      ) : (
        <div className="mt-4 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((report) => (
            <div key={report.id} className="relative">
              {report.duplicateCount > 0 && tab === "duplicates" && (
                <div className="mb-2 flex items-center justify-between rounded-t-xl border border-b-0 border-line bg-lime-soft/70 px-3 py-1.5">
                  <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-forest">
                    grouped thread · {report.duplicateCount + 1} reports
                  </span>
                  <StatusBadge status={report.status} />
                </div>
              )}
              <ReportCard report={report} />
              {report.categoryCorrected && (
                <span
                  className={`absolute right-3 top-14 rounded-full px-2 py-1 text-[9px] font-semibold ${
                    CATEGORY_TONE[report.category] ?? "bg-white text-ink"
                  }`}
                >
                  human-corrected
                </span>
              )}
            </div>
          ))}
        </div>
      )}

      {tab === "duplicates" && filtered.length > 0 && (
        <p className="mt-4 rounded-xl border border-line bg-mist/50 px-4 py-3 text-[11.5px] leading-relaxed text-ink/55">
          <span className="font-semibold text-ink">How grouping works:</span> when a new report scores
          high on wording, category and location similarity, its evidence is attached to the existing
          thread. Residents can still verify separately, so support is never lost.
        </p>
      )}
    </div>
  );
}
